# WO-6.9-e review packet — D5 break-glass honest shell + D6 drill polish (🟠 AMBER)

Branch `e6/wo-6.9-e` off the merged d head (`6f48680`, canon v0.9.4). **Do NOT merge** — founder review. This is the **last console slice** and the most sensitive screen in it (the maker-checker seam).

## What shipped
**D5 — the break-glass honest shell** (PART 8 §5 · §8.3), read-only, the dispatcher's surface of a `HandoffAuthorization`:
- **`break-glass.ts`** — a PURE read-model (`import type` only → no value import, nothing to write/issue with). It consumes the CANONICAL pinned enums `HandoffAuthorizationState` + `AuthorizationSource`. `deriveBreakGlassBoard(view, groundVerified)` renders the state machine **READ-ONLY**: earlier steps done, current marked, later steps `pending` (« en attente »). `provider_confirmed`/`issued`/`consumed` are honestly « en attente » when the operator is still verifying — E3-gated, the console never fabricates a provider confirmation.
- **`BreakGlassView` is a deliberate projection** of the canonical `HandoffAuthorization` that STRUCTURALLY OMITS the `signature` (the fourth secret — the issuing credential never reaches the dispatcher) and every franc figure (`exactAmount` — no franc in Séra), plus the payment-domain fields (`buyerRef`, `providerTransactionReference`). The test proves both absences at type level (`@ts-expect-error` on `view.signature` / `view.exactAmount`, enforced by the typecheck gate).
- **THE ISSUING LEVER DOES NOT EXIST** — proven structurally (the D1/D3/D4 absence pattern): `test/break-glass.test.ts` scans every console `src/*.ts` for issuing surfaces (`issueAuthorization|issueHandoff|authorizeHandoff|grantAuthorization|signAuthorization|issueBreakGlass|advanceAuthorization|confirmProvider|markProviderConfirmed`) → NONE. Issuing is the payment operator's, in the platform ops surface (maker-checker: two different humans).
- **The dispatcher holds the GROUND half only** — the one lever captures « Remise vérifiée sur place » and **never advances the authorization** (`deriveBreakGlassBoard(view,true).steps` deep-equals `(view,false).steps`). Ground-verified ≠ issued. The render states it plainly: « L'autorisation est donnée par l'opérateur de paiement, jamais ici. »

**D6 — drill polish:** the SOS raise→ack path is verified present (WO-6.3, not rebuilt); a new honest drill-status line reads « Exercice de réponse SOS : à faire avant le pilote. » — never a fake « réussi » (a live SOS drill must pass before the pilot, PART 8 §6).

## Evidence
- `WO-6.9-e.diff` — the diff (8 files: break-glass.ts + test + sandbox-break-glass.ts + main.ts render + i18n + gallery states/spec + shell.spec, + JOURNAL). **No `services/` file touched.**
- `logs/branch-log.txt` — the two commits (core, render+D6).
- `cold-gates.log` — the cold-proof law, **both lines shown**: COLD (`export HOME=<fresh empty dir>`, isolated store, ~33 s genuine re-fetch) + AUTH (CI-equivalent `https://` rewrite, config not cache; no url-form change; 0 ssh forms). cold ui-tokens 0.9.4, cold build exit 0, **ALL GATES GREEN**.
- `verifier-verdict.md` — fresh-context verifier verdict.

## Tests / gates
break-glass.test.ts **5/5** (state machine read-only + « en attente » · ground half never advances the authorization · terminal voided/expired · fourth-secret + franc unrepresentable [type] · issuing lever absent + import-type-only). typecheck exit 0 (the `@ts-expect-error` absence proofs load-bearing). Gallery: `console-breakglass` + `console-breakglass-ground` **byte-identical across two runs** (fixed clock). shell.spec.ts updated for five sections (h2 4→5, break-glass heading asserted at nth(3)). copy-lint 0 violations (84 entries; new break-glass strings register:money, solemn). Warm + cold `run-gates.sh` ALL GREEN.

## FORBIDDEN respected
This console **cannot move a franc** (the view omits `exactAmount`; no franc rendered), **cannot fabricate custody** (the board.test console-cannot-write-custody scan covers break-glass.ts), and **cannot issue or shortcut an authorization** (no issuing lever exists; the ground half never advances the state; provider-confirm honestly « en attente »). No ledger/refund/payout · no route/ETA/ranking · journey/custody SERVICE semantics untouched (diff is console + gallery only). The fourth secret (`signature`) is structurally absent from the dispatcher's surface.
