# SERA-S1 review packet — the persistent outbox primitive (🟠 AMBER)

Branch `e6/sera-s1-outbox` off the merged re-pin head (`2a5904b`, canon v0.9.8). **Do NOT merge** — founder review. This is the primitive S2/S3/S4 build on; **nothing is wired through it this slice.**

## What shipped
The device-durable outbox the GP-SERA grounding scoped — the CLIENT half of exactly-once, mirroring the server-side B2.1 pattern already in `assignment-lease.ts`.

- **`src/offline/commandId.ts`** — the offline MINT SEAM (canon derivation `COMMAND-ID-MINT.md`: "APPS adopts `mintCommandId` at its isolated offline seam"). It **adopts** the canon helper — re-exports `mintCommandId`/`CommandIdSchema` from the pure-zod SUBPATH `@platform/contracts/dist/command-id.js` — it does **not** re-implement (re-implementing the branded schema would be canon drift). RN-safe: the subpath, never the `@platform/contracts` barrel.
- **`src/offline/outbox.ts`** — the port-based primitive. `enqueue` mints the `command_id` **ONCE** and persists `{commandId, kind, payload, status:'pending'}`; `restore` reads it back (restore-on-open); `flush` carries each pending entry to the authority **with its persisted id (never re-minted)** and records the surfaced outcome. Outcome vocabulary is the lease's: **`applied | idempotentReplay | collision-refused`** — `applied`/`idempotentReplay` settle and drop; `collision-refused` is **surfaced and kept pending** (never a silent drop). Persistence is an `OutboxStore` port.
- **`src/offline/documentStore.ts`** — the device adapter: `expo-file-system`'s `Paths.document` (the store "safe from being deleted by the system" — survives kill AND reboot, unlike cache) + `File` write/text/exists. Thin I/O; device-only (never runs under vitest).
- **`src/offline/ensureCsprng.ts`** — the device CSPRNG binding: installs `globalThis.crypto.randomUUID` from **expo-crypto** if the runtime lacks it (the founder's ruling: OS CSPRNG, `Math.random` forbidden). Idempotent; not imported by the core or tests (Node's WebCrypto satisfies the mint there).
- **`scripts/check-mint-path-entropy.mjs`** — the **inherited** WO-5.9 gate ("every repo inherits"): no `command_id` mint path may draw from `Math.random`. Two faithful adaptations (documented in-file): walk Séra's `apps/`+`services/`+`packages/`; accept adoption of canon `mintCommandId` as the CSPRNG draw (the derivation's explicit intent). Wired into `run-gates.sh` positive + negative.

## Fixtures (red-first, `test/outbox.test.ts`, 6/6)
- **offline-write-survives-reboot** — enqueue → a FRESH store instance re-reads the committed bytes (a real temp-file store; "reboot" = in-memory gone, only the file persists) → the entry + its `command_id` survive, status still `pending` (SE-I06). Not an in-memory illusion.
- **duplicate-flush-refused-surfaced** — the same `command_id` flushed twice (a lost-ack retry) → `idempotentReplay` **surfaced**, applied **exactly once**. Plus: `collision-refused` surfaced + kept pending.
- **command_id-minted-once-not-per-retry** — three flush retries carry the **identical persisted id** — mint is never re-run (killing the `sos-${riderId}-${raisedAt}` per-attempt anti-pattern).
- adoption proof: `mintCommandId()` yields a valid branded UUIDv4; RN-safe subpath (not the barrel) asserted.

## Evidence
- `SERA-S1.diff` — 11 files (offline modules + adapter + seam + test + the inherited gate + negative fixture + `run-gates.sh` wiring + `package.json` `@platform/contracts` dep + dep-gate registration + relock). **No `App.tsx`, no `custody-flow.ts`, no `demo/store.ts` touched.**
- `logs/branch-log.txt` — the two commits (primitive, gate).
- `cold-gates.log` — both lines: COLD (fresh HOME, isolated store, 28 s genuine re-fetch) + AUTH (https:// rewrite, no url-form change; 0 ssh forms). cold ui-tokens 0.9.8, cold build exit 0, **ALL GATES GREEN**.
- `verifier-verdict.md` — fresh-context verifier verdict.

## Deps / gate notes
`@platform/contracts` is now a rider-app dependency — the home of canon `mintCommandId`, consumed RN-safe via the `/dist/command-id.js` subpath (pure zod). It is registered in the dep-allowlist gate as **baseline `@platform` infra** (the `before` set, like ui-tokens), not an added third-party capability. The two Expo substrates (`expo-crypto`, `expo-file-system`) landed in the re-pin slice; both resolve with types in `apps/rider-app/node_modules`.

## FORBIDDEN respected
The `CONNECTIVITY` constant (`custody-flow.ts`) is **untouched** (S4's). **Nothing is wired** — no write routes through the outbox this slice (grep-confirmed: only the new offline files + the test reference it). Custody semantics untouched (`demo/store.ts` unchanged). No franc, no custody write, no screen. `App.tsx` untouched → the RN-safe shell gate stays green.
