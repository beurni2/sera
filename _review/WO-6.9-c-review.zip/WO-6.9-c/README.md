# WO-6.9-c review packet — D3 the live board (🟠 AMBER)

Branch `e6/wo-6.9-c` off the merged b head (`db50568`, canon v0.9.4). **Do NOT merge** — founder review. 6.9-d branches from c's head when this packet ships.

## What shipped
The dispatch console's **live board** (D3), read-only, per PART 8 §3 + SE-I03/SE-I04:
- **`board.ts`** — a PURE read-model (`import type { RouteManifest }` only; no value import → nothing to write with). `deriveRiderBoard(manifest, custody)`:
  - **SE-I03:** `currentStop = orderedStops[0]` (or null when empty) — exactly one current stop; the rest are `upcomingStops`.
  - **SE-I04:** one `currentCustodian` per package; a manifest package with no custody record **throws « never unowned »** (never rendered owned-by-nobody).
  - **Task status is never custody truth:** `isDivergence = taskStatus === 'delivered' && currentCustodian !== 'customer'` → `render: 'incident'` (custody wins, PART 8 §3), else `'agreement'`. No quiet third state — a divergence is never hidden.
- **The render (`main.ts`)** shows custody truth first (`board-custody`, mapped to « Chez le livreur / Au dépôt / Remis au client »), and when `render==='incident'` a loud incident block: « Incident — la garde fait foi » / « Le statut annonce « livré », mais le colis est encore en garde. On suit la garde, jamais le statut seul. » READ-ONLY: the (aperçu) levers only swap the demo custody snapshot — no custody write.
- **Fixture — console-cannot-write-custody** (`test/board.test.ts`, the D1 structural pattern): scans every console `src/*.ts` for custody-mutating tokens → NONE; asserts board.ts has zero value imports. The console renders custody; the custody-service is the sole authority.

## Evidence
- `WO-6.9-c.diff` — the diff (9 non-review files: board.ts + board.test.ts + main.ts render + sandbox-board.ts + i18n + gallery states/spec + shell.spec update).
- `logs/branch-log.txt` — branch commit log (by name).
- `cold-gates.log` — the cold-proof law, **both lines shown**: COLD (`export HOME=<fresh empty dir>`, 696 MB pnpm store isolated, 31.9 s re-fetch) + AUTH (CI-equivalent https:// rewrite, config not cache; **no url-form change** — 0 ssh forms). cold ui-tokens 0.9.4, 0-cached build, **ALL GATES GREEN**.
- `verifier-verdict.md` — fresh-context verifier verdict.

## Tests / gates
board.test.ts **5/5** (SE-I03 · SE-I04 + ghost-throw · delivered-but-held → incident · agreement path · console-cannot-write-custody). Gallery: two board states **byte-identical across two runs** (fixed clock; the board has no wall-clock content). shell.spec.ts updated for three sections (queue/board/follow-up), h2 2→3 + the board heading asserted — a strengthening. copy-lint 0 violations (money/trust register). Warm + cold `run-gates.sh` ALL GREEN.

## FORBIDDEN respected
No ledger write · no refund/payout lever · **no route/ETA/ranking/distance model** (the board ranks nothing) · no franc in sera · journey/custody SERVICE semantics untouched (the diff is console + gallery + i18n only). The board is a read model over custody truth; it cannot move a franc or mutate a CustodyRecord.
