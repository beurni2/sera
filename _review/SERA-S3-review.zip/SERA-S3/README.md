# SERA-S3 review packet — SOS on the outbox (🟠 AMBER)

Branch `e6/sera-s3-sos-outbox` off the merged S1 head (`b20a5cb`, canon v0.9.8). **Do NOT merge** — founder review. This is the drill's software half — the last durability slice before the physical SOS drill.

## What shipped
The rider's SOS raise now rides the S1 outbox — the CLIENT half of exactly-once for a safety signal.

- **`src/offline/sos.ts`** — the durable SOS layer. `appendSosRaise(store, commandId, intent)` persists `{commandId, kind:'sos.raise', payload, status:'pending'}` to the outbox with the **already-minted** `command_id` (minted once at the gesture). It owns only durability; the in-memory incident + its honesty laws stay in `demo/store.ts`.
- **`src/offline/outbox.ts`** — added `append(store, entry)` (persist a pre-built entry whose id was minted at intent, for instant UI); `enqueue` is now `mint + append` — behaviour unchanged (S1's 6 fixtures still pass).
- **`demo/store.ts` — the timestamp id DIES.** `raiseSos` now takes a `commandId: CommandId` and the incident `id` **is** that command_id (`correlationId = corr-${commandId}`), replacing the retired per-attempt `sos-${riderId}-${raisedAt}` (an id a reboot-retry regenerated → two SOS for one press, or a lost SOS shown pending). **`acknowledgeSos` is untouched** (structurally unfakeable — throws on a non-live incident). No custody function changed.
- **`App.tsx` — the wiring.** `fireSos` mints the command_id **once** at the gesture, raises the in-memory incident **instantly** (a safety SOS never waits on disk), then persists via `appendSosRaise` in the background (`void …`) to the document-dir store. New imports are all **relative** (`./src/offline/*`) — never the `@platform/contracts` barrel; the RN-safe shell gate stays green.

## Fixtures (red-first, `test/sos-outbox.test.ts`, 3/3)
- **offline-sos-survives-reboot-then-flushes-once** — the raise persists; a fresh temp-file store re-reads committed bytes (reboot); a duplicate flush of the SAME command_id → `idempotentReplay`, the SOS **created exactly once** (never two for one press, never zero).
- **sos-id-stable-across-retry** — three flush retries carry the **identical** command_id; it is a canon UUIDv4 and does **not** match `/^sos-/` (the retired format is dead).
- **queued-sos-still-unacknowledgeable** — an offline (queued) SOS with a command_id id still throws on `acknowledgeSos`, stays queued, emits nothing — the ack law unchanged.

Existing SOS tests stay green with the new signature: `sos-drill.test.ts` **9/9** (responder-match + queued-unacknowledgeable), `demo-store.test.ts` **12/12**.

## Evidence
- `SERA-S3.diff` — 6 files (outbox `append`, the durable SOS layer, the `raiseSos` id change, the App.tsx wiring, the two test files). **`custody-flow.ts` (CONNECTIVITY) untouched; no custody function changed.**
- `logs/branch-log.txt` — the single S3 commit.
- `cold-gates.log` — both lines: COLD (fresh HOME, 26 s re-fetch) + AUTH (https:// rewrite, no url-form change; 0 ssh forms). cold ui-tokens 0.9.8, cold build exit 0, **ALL GATES GREEN**.
- `verifier-verdict.md` — fresh-context verifier verdict.

## Verifier: PASS, no blocking (one flagged observation)
The fresh-context verifier confirmed A–H by its own hands, including the non-vacuity proof (break the dedup → the SOS is created twice, the fixture FAILS). Its one observation: the background persist `void appendSosRaise(...)` is fire-and-forget with no `.catch`. **Flagged, not fixed** — the verifier confirmed the safety invariant holds regardless (no SOS lost or doubled; the in-memory incident already showed). A `.catch` would only handle error-noise, and there is no error surface to route a persist failure to in this slice, so it's a one-line hardening for a later slice, not a safety fix worth churning the shell for post-verifier.

## FORBIDDEN respected
The `CONNECTIVITY` constant is **untouched** (S4's — `git diff -- custody-flow.ts` empty). The ack path is **unchanged** (no +/- on `acknowledgeSos`). No franc, no custody write; the custody functions in `demo/store.ts` are byte-unchanged (only `raiseSos` changed). Warm + cold `run-gates.sh` **ALL GREEN**; S1's outbox fixtures (6/6) and the mint-path-entropy gate stay green.
