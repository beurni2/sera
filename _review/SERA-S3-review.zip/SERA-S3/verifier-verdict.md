# SERA-S3 — fresh-context verifier verdict (verbatim)

Fresh-context verifier subagent "Fresh-context verifier: SERA-S3 SOS outbox". No memory of the
build; given only the quoted spec, the diff (b20a5cb..cb59bfe), and the DoD. Verified (A)–(H)
by its own hands (27 tool calls, ~316 s). Tree left clean.

---

**VERDICT: PASS**

**BLOCKING: none**

- **(A) SOS raise routes through the outbox — durable, flushes once — PASS.** `appendSosRaise` (`src/offline/sos.ts:38`) calls `append(store, { commandId, kind: SOS_RAISE_KIND, payload: intent, status: 'pending' })` — SOS_RAISE_KIND is `'sos.raise'`. `pnpm --filter @sera/rider-app exec vitest run test/sos-outbox.test.ts` → `Tests 3 passed (3)`. In `offline-sos-survives-reboot-then-flushes-once`, a fresh `fileStore` re-reads committed bytes (`afterReboot` length 1, same commandId, kind `sos.raise`), then a re-queued duplicate of the SAME id flushes to `idempotentReplay` and `created` = `[commandId]`. **Non-vacuity proven by my own hands:** I dropped a mutant test into `test/` with dedup broken (`send` always returns `applied`, no `seen` set), ran it, and the "created exactly once" assertion FAILED: `expected [ …(2) ] to deeply equal [ Array(1) ]` — the same command_id created twice. Removed the throwaway; `git status` shows no tracked-file change.

- **(B) The timestamp id dies — PASS.** `raiseSos` (`demo/store.ts:403`) sets `id: commandId` and `correlationId: \`corr-${commandId}\``; the old `id: sos-${riderId}-${raisedAt}` / `corr-sos-…` lines are `-` in the diff. Grep of `apps/rider-app/src/` for `sos-${` returns exactly 3 hits — all comment lines (`store.ts:388`, `sos.ts:14`, `outbox.ts:12`) documenting the retired pattern, zero live code. `raiseSos` takes `commandId` as a parameter and never mints — so it structurally cannot re-mint per call; the sole live caller `App.tsx:311-312` mints once with `mintCommandId()`. The `sos-id-stable-across-retry` fixture passes: 3 `collision-refused` retries carry `[commandId, commandId, commandId]` (set size 1), the id matches `/^[0-9a-f]{8}-…-4[0-9a-f]{3}-[89ab]…/i` and NOT `/^sos-/`. Empirically the minted id in my mutant run was `cb71c21f-29cc-4a85-a64b-210aeaca901d` — a valid UUIDv4.

- **(C) Ack path unchanged — PASS.** `git diff b20a5cb..cb59bfe -- apps/rider-app/src/demo/store.ts` filtered for `acknowledgeSos`/custody-fn names → "NO +/- lines touch acknowledgeSos or custody fns"; the only store.ts changes are the `CommandId` import, the `commandId` param + comment, and the `id`/`correlationId` lines. `queued-sos-still-unacknowledgeable`: a queued incident whose `id === commandId` still throws on `acknowledgeSos`, stays `queued`, `events []`. `test/sos-drill.test.ts` → `9 passed (9)` (responder-match + queued-unacknowledgeable laws hold).

- **(D) CONNECTIVITY untouched — PASS.** `git diff b20a5cb..cb59bfe -- apps/rider-app/src/custody-flow.ts | wc -l` → `0` (empty diff); no CONNECTIVITY line in the diff. Untouched (S4's).

- **(E) App.tsx wiring, RN-safe — PASS.** `fireSos` mints `const commandId = mintCommandId()` ONCE (line 311), raises the in-memory incident synchronously (`const raised = raiseSos(world, commandId, …)`, line 312), sets `status = raised.status`, and persists via `void appendSosRaise(sosStore, commandId, …)` in the background (line 320) — same commandId to both the raise and the append, so one id backs both the shown incident and the durable entry. All three new imports are relative `./src/offline/*`; grep for `@platform/contracts` in App.tsx → none. `test/shell.test.ts` → `3 passed (3)` (barrel-ban gate green). Minor non-blocking observation: the background persist is fire-and-forget with no `.catch`; a disk-write rejection would be unhandled — but this is the spec's deliberate "instant UI, background persist" and loses/doubles nothing beyond the inherent kill-window in which the in-memory incident is also gone.

- **(F) Outbox append refactor safe — PASS.** `outbox.ts` adds `append` (persist a pre-minted entry) and `enqueue` now = `mintCommandId()` + `append` — enqueue's observable behavior unchanged. `test/outbox.test.ts` → `6 passed (6)`. `node scripts/check-mint-path-entropy.mjs` → exit 0: "1 mint path(s) draw from the OS CSPRNG … zero Math.random".

- **(G) Forbidden + scope — PASS.** Comment-stripped scan of `sos.ts` for `FCFA|franc|montant|dropCode|captureEvidence|seal|custody` → CLEAN; added raiseSos lines carry no franc/custody token. Custody functions (`captureEvidence`, `validateDropCode`, `passVerification`, `registerSeal`, `beginPickup`, etc.) are not in the diff. Changed-file list is exactly the six expected: `App.tsx`, `demo/store.ts`, `offline/outbox.ts`, `offline/sos.ts`, `test/sos-drill.test.ts`, `test/sos-outbox.test.ts`. (`documentStore.ts`, imported by App.tsx, pre-existed at base b20a5cb and is unchanged.)

- **(H) Gates — PASS.** `PW_EXECUTABLE=/opt/pw-browsers/chromium bash scripts/run-gates.sh` → exit code 0, final line "ALL GATES GREEN (positives passed; every negative fixture failed as required)" (the drift-check "TAMPERED doc (must fail)" block is a negative fixture, correctly failing by design; dispatch-console Playwright 22 passed). Full rider-app suite `pnpm --filter @sera/rider-app exec vitest run` → `12 passed (12) / Tests 78 passed (78)`, including sos-outbox 3, sos-drill 9, outbox 6, shell 3, demo-store 12.

No SOS can be lost or doubled on this path (one persisted command_id, at-least-once with idempotent dedup, proven non-vacuous). The timestamp id survives nowhere live. The ack path, CONNECTIVITY, and custody semantics are byte-untouched. App.tsx imports no barrel. S1's outbox fixtures hold. Every gate is green.

---

## Builder disposition of the (E) observation (non-blocking)
The background persist `void appendSosRaise(...)` is deliberate fire-and-forget (instant UI on a safety SOS). The verifier confirmed the safety invariant holds regardless — no SOS is lost or doubled. A `.catch` here would only handle error-noise, and there is no error surface to route a persist failure to in this slice. **Flagged, not fixed** — churning the safety shell post-verifier for a noise nicety isn't warranted; it is a clean one-liner (`.catch` + a real surface) for a later hardening slice. The safety guarantee stands.
