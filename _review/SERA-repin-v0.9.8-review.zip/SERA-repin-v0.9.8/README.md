# SERA re-pin v0.9.4 → v0.9.8 — review packet (🟠 AMBER)

Branch `e6/sera-repin-v0.9.8` off the merged main head (`1273484`, was canon v0.9.4). **Do NOT merge** — founder review. This is the **prerequisite slice** the SERA-S1 STOP surfaced: `mintCommandId` (the v0.9.5 command_id rule) and the two device substrates did not exist at our v0.9.4 pin. S1 branches from this merged head.

## What shipped
A pure canon re-pin + the two authorized rider-app deps — **no product code**.
- **All 8 pin sites** moved `04af4b5` (v0.9.4) → **`67bda02646019cb4ab28a16fadf388b522da2799`** (v0.9.8 release merge): 7 `package.json` specifiers + `pnpm-workspace.yaml` overrides (contracts, i18n, ui-tokens, **kernel-types**). Zero occurrences of the old sha remain; **0 ssh-form URLs** in the regenerated lockfile.
- **Installed `@platform/contracts` prints 0.9.8**, and — the point of the re-pin — **`mintCommandId` is now exported** (`dist/command-id.js`; `index.d.ts:14 export * from './command-id.js'`). It did not exist at v0.9.4; introduced at v0.9.5 (« the command_id mint rule — UUIDv4 · OS CSPRNG · Math.random forbidden »).
- **Drift-check bumped `--pinned-version 0.9.4 → 0.9.8`** (both the positive gate and the negative fixture). **`drift-check OK: 11 canonical docs match manifest (packageVersion 0.9.8)`.** The tracked `/docs` were **NOT hand-edited** — `git diff 1273484..abc6126 -- docs/` is **empty**: the 11 tracked docs are byte-identical v0.9.4→v0.9.8 (the v0.9.5–8 canon deltas were in contracts **code/schemas**, not the tracked prose), so the re-sync from `platform-contracts@67bda02:docs/` was a verified no-op.
- **Two authorized deps, registered not smuggled.** `apps/rider-app/package.json` declares **`expo-crypto ~15.0.9`** (the founder's command_id ruling mandates it for RN; Hermes has no `crypto.randomUUID` without it) and **`expo-file-system ~19.0.23`** (the durable document-dir store — boutik's `expoDocumentStore` precedent; survives kill+reboot). Both are the **SDK-54 bundled versions** (from `expo/bundledNativeModules.json`), both resolved in the lockfile. Sera's **dep-allowlist gate is a test** — `apps/rider-app/test/grand-teint.test.ts` "the approved dependencies — nothing else" — updated to register exactly these two (its `added.sort()` now lists 5). *(Note per the WO: sera's dep-gate is this test, not a `scripts/gates/` file — registration is by updating its allowlist, which is the gate's purpose.)*
- **Provenance note:** boutik declares **neither** module (only `expo ~54.0.35`, same SDK) — so `expoDocumentStore` is the *pattern* to mirror, not a live version to copy; the SDK-54 bundled versions are the honest pick.

## D5 exposure anchor (CTO-requested)
v0.9.8 constrained `HandoffAuthorization.authorizedBy` to `ops:payment:*`. The console's break-glass read model is **unaffected**: `grep -c authorizedBy apps/dispatch-console/src/break-glass.ts` → **0** (`BreakGlassView` omits `authorizedBy` — the payment-operator constraint does not touch the dispatcher's projection). break-glass.test.ts stays green.

## Evidence
- `SERA-repin-v0.9.8.diff` — the diff (11 files: 8 pins + `pnpm-lock.yaml` + `run-gates.sh` drift-version + `grand-teint.test.ts` dep-registration). **No `docs/`, no product `src/*.ts`.**
- `logs/branch-log.txt` — the single re-pin commit.
- `cold-gates.log` — both lines: COLD (fresh HOME, isolated store, 26 s genuine re-fetch — contracts 0.9.8 + both new Expo deps fetched cold) + AUTH (CI-equivalent `https://` rewrite, no url-form change; 0 ssh forms). cold ui-tokens 0.9.8, cold build exit 0, **ALL GATES GREEN**.
- `verifier-verdict.md` — fresh-context verifier verdict.

## Gates
Warm + cold `run-gates.sh` **ALL GATES GREEN, exit 0**. drift-check 0.9.8 (11 docs). Rider-app dep-allowlist test green (5 registered deps). Console + service tests green. 0 ssh-form URLs.

## Verifier verdict: PASS, no blocking (one flag for the record)
The fresh-context verifier (`verifier-verdict.md`, verbatim) confirmed all 7 DoD points by its own hands. Its one non-blocking flag: the retired sha `04af4b5` still appears **70×** inside the tracked `_review/WO-6.9-slice1/` archive (its `repin.diff` + `verifier-verdict.md`) — a **frozen review record** of the prior 0.9.0→0.9.4 re-pin, *not* a build/resolution pin site, correctly untouched by this diff. No resolvable pin references the old sha. Scrubbing a historical review artifact would falsify what it recorded, so I left it; if you want the tree literally free of the old sha anywhere, that's a separate cleanup call — flagged, not taken.

## FORBIDDEN respected
No product code changed (pins + lockfile + drift-version + dep-gate registration only). No custody semantics touched. The `CONNECTIVITY` constant is untouched (S4's). No write is routed through any outbox in this slice (there is no outbox yet — S1). The two deps are declared but **not yet imported** anywhere.
