# WO-6.9-d review packet — D4 the exceptions desk (🟠 AMBER)

Branch `e6/wo-6.9-d` off the merged c head (`a893e47`, canon v0.9.4). **Do NOT merge** — founder review. 6.9-e (D5 break-glass + D6) branches from d's head when this packet ships.

## What shipped
The dispatch console's **exceptions desk** (D4, "the most important screen in the building"), read-only, per PART 8 §4 + Sera-Build-Spec §6.5 + SE-I10:

- **`exceptions.ts`** — a PURE read-model (`import type` only → no value import, nothing to write with). `deriveDeskRow(outcome, evidence, custody)`:
  - **The outcome family + reason are CANONICAL PINNED TYPES** (`@platform/contracts` v0.9.4): `family: DeliveryOutcomeFamily` is exactly `['retry','reschedule','return','incident']`; `reasonCode: DeliveryFailureReason` is one of the eight structured codes. So a **generic « échec »/"failed" is unrepresentable BY CONSTRUCTION**, not by discipline — this is why the re-pin (slice-1) preceded the desk (v0.9.4 ratified the four-member family with `return`).
  - **SE-I10 — never unowned:** a desk row whose package has no custodian **throws** « never unowned » (custody stays with the rider or the hub until the two-key return handoff).
  - **Structured, not free-floating:** the evidence must be FOR the package in custody (`evidence.packageId !== custody.packageId` throws).
- **The render (`main.ts`)** shows, per row: the structured reason (via its register-tagged `humanReasonRef` catalog key), the **ONE** applied outcome (`console.family_${family}`), the custodian (never unowned), evidence-attached, and a loud incident block only when `family === 'incident'`. READ-ONLY: the (aperçu) levers only swap the demo set — no custody write, no refund/payout lever, no franc.
- **Fixture — generic-failure-unrepresentable** (`test/exceptions.test.ts`): type-level `@ts-expect-error` proofs (verified by the typecheck gate) that `'échec'`/`'failed'` is not a `DeliveryOutcomeFamily` and that `reasonCode`/`family` cannot be omitted, plus a runtime witness that `DELIVERY_OUTCOME_FAMILIES` deep-equals the four and excludes any generic-failure token.

## Evidence
- `WO-6.9-d.diff` — the diff (8 code files: exceptions.ts + test + sandbox-exceptions.ts + main.ts render + i18n + gallery states/spec + shell.spec update, + JOURNAL). **No `services/` file touched.**
- `logs/branch-log.txt` — the three commits (core, render, CSS-collision fix).
- `cold-gates.log` — the cold-proof law, **both lines shown**: COLD (`export HOME=<fresh empty dir>`, isolated store, 37 s genuine re-fetch) + AUTH (CI-equivalent `https://` rewrite, config not cache; **no url-form change** — 0 ssh forms). cold ui-tokens 0.9.4, cold contracts pin `04af4b5`, cold build exit 0, **ALL GATES GREEN**.
- `verifier-verdict.md` — fresh-context verifier verdict (**PASS**, no blocking). It verified `895ba9f` and raised two non-blocking nits; the header records how each was handled.

## Post-verifier fix + one flag (transparency)
- **Nit #2 — FIXED in `e87b47e` (shipped head).** The desk `<section>` reused the class `.desk`, colliding with the existing `.desk` header-overline rule (`text-transform: uppercase` + accent) → the whole desk rendered UPPERCASE (a real visible defect, not just latent). Renamed the section class to `.exceptions-desk`. Re-verified at `e87b47e`: typecheck 0 · 23/23 unit · 20/20 e2e · both desk states byte-identical across two runs · warm + cold gates GREEN · visually confirmed warm proper-case.
- **Nit #1 — FLAGGED, not fixed.** `@platform/contracts` is imported by the console (type in `exceptions.ts`, value `DELIVERY_OUTCOME_FAMILIES` in the test) but not declared in `apps/dispatch-console/package.json` (resolves via hoisting; all gates green). This is **pre-existing from board.ts (D3, already merged)** and its proper fix touches the pinned-package declaration + relock machinery — out of scope for a D4 render slice. Recommend a small hygiene follow-up that adds the declaration for board + desk together.

## Tests / gates
exceptions.test.ts **7/7** (one-of-four family + structured reason · incident loud · SE-I10 never-unowned throw · evidence-binds throw · generic-failure-unrepresentable type+runtime · every family has a catalog label · read-model import-type-only). typecheck exit 0 (the `@ts-expect-error` proofs are well-formed and enforced). Gallery: `console-desk` + `console-desk-incident` **byte-identical across two runs** (fixed clock). shell.spec.ts updated for four sections (queue/board/desk/follow-up), h2 3→4 + the desk heading asserted — a strengthening. copy-lint 0 violations (68 entries; the 8 new desk strings register-tagged). Warm + cold `run-gates.sh` ALL GREEN.

## FORBIDDEN respected
No ledger write · no refund/payout lever · **no route/ETA/ranking/distance model** (the reason→family pairing is illustrative demo data, never an encoded rule — the human decides, PART 8 §1) · no franc in sera · journey/custody SERVICE semantics untouched (the diff is console + gallery + i18n only). The desk is a read model over canonical outcome/evidence types; it cannot move a franc or mutate a CustodyRecord.
