# WO-4.3 lockfile diff purity note
- Before install: 51 occurrences of pin 539dbc8 in pnpm-lock.yaml; 28 pre-existing hybrid git-URL forms (git+https://git@github.com:).
- `CI=true pnpm install` (non-frozen, ERR_PNPM_OUTDATED_LOCKFILE first proved the frozen guard bites): +22 packages.
- After: 51 occurrences of 539dbc8 (NO pin drift); 28 hybrid forms (UNCHANGED — the incremental resolution rewrote no git-dep URL forms, so the conditional normalization step did not apply); `git diff pnpm-lock.yaml` = 483 insertions, 0 deletions — purely additive; added subtree is exactly the miniflare/esbuild/workers-types closure (miniflare 4.20260708.1, workerd 1.20260708.1, esbuild 0.25.12 et al).
- `CI=true pnpm install --frozen-lockfile` on the committed bytes: exit 0 (FROZEN_OK).
- Note: pnpm prints "Ignored build scripts: esbuild, workerd, sharp" — same posture as boutik-plus (its pnpm-workspace.yaml allowlists only @platform/*); esbuild/workerd resolve platform binaries via optional deps, no build script needed. Verified live: the esbuild bundle + Miniflare e2e runs below succeeded.
