# WO-4.3 builder code map — read-before-write state-back

Written BEFORE any code. Every file below was read in full this session.

## A. What exists today, in my own words

### services/logistics-service (the store layer the DO hardens)
- `src/manual-assignment.ts` — `AssignmentBook`: the E1 manual-assignment store.
  `assign(cmd)` re-runs SE1.1 at assignment time (`queue.recheckAssignable`),
  consults `registry.isAssignable`, enforces one-active-per-rider AND per-task
  by scanning its own map, emits `pickup.assigned.v1` (PlatformEventSchema-parsed,
  actor `dispatcher:<id>`), caches ONLY successes by `command_id` (refusals
  re-evaluate — the WO-1.2 retry-after-heal law), computes
  `ackDeadline = at + ACK_DEADLINE_MS (5 min)`. `acknowledge(id, confirmation)`:
  server_confirmed → `acknowledged`; queued_offline → `ack_pending_offline`
  (pending, deadline still bites). `expireUnacknowledged(nowIso)`: any
  awaiting-ack assignment past deadline → `returned_to_queue` + `queue.requeue`
  + `assignment.expired.v1` (actor `logistics-service:ack-deadline`, command
  `expire-<assignmentId>`). `findOneActiveViolations()` feeds tests/scripts.
  Its header explicitly says the atomic AssignmentLease DO "is E4/M2 and is
  explicitly NOT built here" — THIS order builds it.
- `src/ready-queue.ts` — SE1.1 intake: strict event/task parse, admission gate
  (funded FULL_PREPAY + readiness + non-cancelled + NOT STALE), the same gate
  re-run by `recheckAssignable` (adds `not_in_queue`/`already_assigned`/`task_closed`),
  `markAssigned`/`requeue` (requeue never resurrects `closed_rescheduled`),
  `closeRescheduled` (WO-2.7). QueuedTask carries `correlationId` — lineage I
  must assert survives expiry.
- `src/rider-registry.ts` — SE0.2: certification + versioned privacy ack +
  shift lifecycle with offline-pending states; `isAssignable` = certified AND
  server-confirmed `on_shift`; SE3.2 end-shift-with-custody exception.
- `src/reschedule.ts` — WO-2.7 `RescheduleBook`: strict `reschedule`-family
  outcome opens ONE follow-up task (new id, same order, lineage as LOCAL
  record); prior task closes only when the replacement is admitted; the
  follow-up re-runs the FULL intake gate. No custody surface (structural test).
- `src/assignment-authority.ts` — the SE-I01 SEED: pure
  `findAssignmentAuthorityViolations(leases)` over canon `AssignmentLease[]`;
  consumed by the one-assignment-authority gate + its fixtures
  (`gates/fixtures/leases.single-authority.json`, `negative/leases.double-assignment.json`).
  My DO's `toCanonicalLease` projection must feed this exact shape.
- `src/index.ts` — barrel; re-exports every module; type-only canon imports.
- Tests: `manual-assignment.test.ts` (the file whose `assign` call sites I must
  update — 10 tests incl. per-rider/per-task one-active, stale-at-assign,
  retry-after-heal, offline-ack pending + expiry), `reschedule.test.ts`,
  `rider-registry.test.ts`, `intake-misbehavior.test.ts` (§3 mock misbehavior ×8
  both mocks), `delivery-location.test.ts`, `health.test.ts`.
- `package.json`: no worker toolchain yet (typescript/vitest only); dep pin
  539dbc8a. `tsconfig.json` includes `src` only.

### The E1 stock-DO pattern I am mirroring (boutik-plus, read-only)
- `src/stock-reservation.ts` — ALL law in a pure `decideStock(state, cmd)`;
  refusals carry zero mutation; ONLY applied commands recorded
  (`appliedCommands[command_id]`), replay returns `idempotentReplay: true`
  with the same outcome; refusals are never cached.
- `worker/stock-reservation-do.ts` — thin DO: read state key, decideStock,
  persist only `ok && !idempotentReplay`, `Response.json(decision, 200|409)`;
  default-export router maps `/stock/:variantId` → `idFromName(variantId)`,
  refuses body/URL mismatch 400.
- `test/stock-do.e2e.test.ts` — Miniflare on `dist-worker/stock-worker.mjs`
  (`durableObjects: { STOCK_RESERVATION: 'StockReservationDO' }`), 20-way
  `Promise.all` race → exactly 1 winner, replay probe, isolation probe.
- `package.json` — the versions I copy EXACTLY:
  `@cloudflare/workers-types ^4.20250705.0` · `esbuild ^0.25.5` ·
  `miniflare ^4.20250705.0`; scripts: `bundle:worker` (esbuild CLI →
  `dist-worker/stock-worker.mjs`, `--bundle --format=esm --platform=neutral
  --conditions=import`), `pretest: pnpm bundle:worker`, typecheck runs the
  extra `worker/tsconfig.json` (noEmit, types workers-types, moduleResolution
  Bundler, includes the pure src module). platform-contracts'
  `assembly/scripts/bundle-flag-worker.mjs` shows the same esbuild treatment
  in mjs form; boutik uses the CLI form — I mirror boutik (the named class).

### Canon shapes (pin 539dbc8a, v0.6.0)
- `AssignmentLeaseSchema` = `{ taskId, holder, riderId, version int ≥1,
  status string min 1 }` `.strict()` — I must NEVER add fields to it; richer
  fields live in a LOCAL LeaseRecord with a `toCanonicalLease` projection.
- `PlatformEventSchema.name` is a pinned enum; `assignment.declined.v1` IS in
  the union (verified in dist/events.js line 78) — no event invention needed.

### apps/dispatch-console (vanilla TS/DOM + vite; NOT React)
- `main.ts` — tokens → CSS custom properties; one `render(statusKey?)` that
  redraws `#queue-body` from `queue.queuedTasks()`: status line (class
  `status-line`), task cards landmark-first, rider select + assign button.
  Assign click calls `book.assign` with STATIC ids
  (`cmd-console-assign-<taskId>`, `as-<taskId>`) and renders
  `console.waiting_ack` on success. A 60 s `setInterval` calls
  `book.expireUnacknowledged(new Date())` and renders `console.requeued`.
  WO-2.2 follow-up card: dwell + door-signal follower (« Essai » action) +
  static outcome timeline. All strings via `t()` from `i18n/catalog.json`.
- `sandbox-world.ts` — the REAL service classes against well-behaved §3 mocks;
  one funded/ready order, one task `task-e1-0001`, one certified on-shift
  rider `rider-issa`; returns `{queue, book, registry, riders}`.
- `sandbox-followup.ts` — STATIC sandbox data: dwell view, outcome timeline,
  the door-paid provider-class signal. There is NO "mark done"/completion
  surface anywhere in the console sandbox (relevant to BUILD item 3's
  completion wiring — see D9 below).
- `door-signal.ts` — strict-parsed, provenance-checked, deduped view follower.
- `i18n.ts` — catalog-only strings; runtime import ban tested.
- `e2e/shell.spec.ts` — asserts theme booting, TWO h2 sections, the door line
  signal-driven, and the assign flow: after assign,
  `#queue-body .status-line` `toHaveText("En attente de l'accord du livreur.")`
  and `.task-card` count 0. NOTE: `toHaveText` on that locator requires it to
  stay UNIQUE — my new deadline line must use a DIFFERENT class.
- `e2e/gallery.spec.ts` — re-captures `gallery/img/*.png` from
  `gallery/states.json` actions (`assign`, `door-demo`, `clock-6min` with
  `page.clock`). Because my console change adds a visible deadline line, the
  re-captured PNGs will differ in CONTENT; per the order's FORBIDDEN clause I
  discard ALL `gallery/img/` changes after gates runs (`git checkout --`).
- `test/catalog.test.ts` — every static `t('…')` key must exist; NO inline
  accented French in `src/main.ts` code; no runtime canon-barrel imports.

### apps/rider-app (Expo RN, SDK 54)
- `App.tsx` — WO-4.2R face over the WO-4.1 walkable world. The RATIFIED
  navigation law: go() only along JOURNEY edges; toCourses/back are waypoint
  resets, NO pop arm; the go/toCourses/back/reset/walk/openCourse block is
  pinned by tests (I do not touch go/toCourses/back/walk/openCourse; reset()
  gains only my new state reset). The affectation screen: LandmarkCard +
  (ack==='ack_pending' ? PendingNotice+pickup : ack action). The retry_window
  screen is my pattern precedent for a deadline: local `windowUntil` state
  (HH:MM computed with `Date.now() + 15*60_000` + a comment that the live
  value arrives at assembly) shown in a warn StatusChip, and a GhostButton
  « Le temps est passé » demo lever driving the store expiry.
- `src/demo/store.ts` — every custody move `expectStep`-guarded; closed
  courses never move; seeds: Awa (happy), Salif (2e passage), Mariam (retour),
  Issouf (the OFFLINE branch seeded visibly — my precedent for seeding the
  offline-decline state). `ack: 'none' | 'ack_pending'` (queued = pending,
  confers nothing). `captureEvidence(world, id, connectivity = CONNECTIVITY)`
  is the store's convention for server-confirmed vs offline-pending arms —
  the convention my `declineCourse` follows.
- `src/journey.ts` — screens/edges as DATA, rule-owned edges computed from
  custody-flow; COURSE_OPEN_STEPS includes 'affectation'. I add NO screen and
  NO edge (decline/expiry are course-STATE changes rendered on the existing
  affectation screen + course list, exactly like refused courses).
- `src/ui/kit.tsx` — the WO-4.2R kit; I use ONLY StatusChip / PendingNotice /
  PrimaryButton / DangerButton / GhostButton — zero new styles, zero raw values
  (the ui-kit scan bites on any hardcoded size/color in App.tsx or kit.tsx).
- `src/custody-flow.ts` — rule source; CONNECTIVITY = 'online' typed data.
  UNTOUCHED by this order.
- Tests: `ui-kit.test.ts` (scan + pattern pins incl. PendingNotice lines for
  ack_pending — my affectation rework keeps that exact JSX), `shell.test.ts`
  (catalog coverage of every static `t('…')` + no inline accented French in
  App.tsx), `journey-spine.test.ts` (BFS + back-law pins — untouched edges keep
  it green), `demo-store.test.ts` (NOTE: asserts
  `Object.keys(store).filter(/door|signal|pay/i)` === exactly
  `['applyProviderDoorSignal']` — my new store exports must avoid those
  substrings: `declineCourse`, `expireProposal` are safe), `preview-banner.test.ts`.
- `i18n/catalog.json` — 81 entries, register+screenClass tagged; rider copy
  consistently TUTOIES (« pas de toi », « Dis-nous », « le tien »).

### Gates & harness
- `scripts/run-gates.sh` — typecheck → `pnpm test` (turbo: test dependsOn
  build, so dist + console dist rebuild before tests) → baseline/quote checks →
  every invariant gate with its negative fixture (exit-1-exact law) →
  copy-lint both catalogs (banned-register tokens, register-mismatch,
  reading budgets per screenClass; label class exempt; budgets bind sentences
  of ≥4 words) → drift-check 0.6.0 → Playwright e2e (shell + gallery).
- `scripts/gates/one-assignment-authority.mjs` — parses a lease-array fixture
  with the PINNED AssignmentLeaseSchema then enforces ≤1 active per task.
  My projection test proves DO output parses with the same schema; fixtures
  need no change (extension allowed additively if needed — not needed).
- `scripts/gates/rider-assignability.mjs` — drives the BUILT dist
  RiderRegistry; unaffected by my change.
- `scripts/e1-dispatch-happy-path.mjs` — calls `book.assign(...)` WITHOUT a
  lease: MUST be updated for the new required argument (test-local witness,
  same treatment the WO prescribes for manual-assignment.test.ts). All its
  assertions preserved verbatim.
- Repo-source scan gates: I checked every banned pattern list. Watchouts for
  my code/comments: never write "auto-release"/"release funds"
  (no-evidence-release), no "wallet/balance" words, `releaseOnCompletion`
  does NOT match any banned regex (verified against
  `/release[_-]?(on[_-]?)?evidence/` — needs the literal "evidence").
- JOURNAL tail (WO-4.1/4.2R): the two-level waypoint ladder is RATIFIED law;
  kit conventions (tokens only, honest states); tooling laws — gallery PNG
  re-encodes discarded before closing commits; cold-proof isolation dirs
  short. The catalog/copy-lint discipline: strings only in catalogs.

## B. How the change fits (design, per the CTO's decisions)

1. **`src/assignment-lease.ts` (new, pure)** — the stock-reservation pattern:
   `decideLease(state, cmd)` with commands `acquire | release | expire_due`,
   refusal reasons exactly `eligibility_not_attested / rider_already_leased /
   task_already_leased / no_active_lease` (+ a boundary-guard
   `malformed_command` for unparseable timestamps / empty ids / unknown cause —
   validation at the system boundary, mirroring stock's `invalid_qty` class).
   Acquire checks rider-lease BEFORE task-lease (WO order; makes race ① yield
   19 × task_already_leased and race ② 19 × rider_already_leased).
   LOCAL `LeaseRecord {taskId, riderId, grantedAt, expiresAt, correlationId,
   eligibilityCheckedAt, version, status, releaseCause?}` — no field beyond
   the WO list. Per-task version counters (fresh lease after expiry = version+1).
   ONLY successes cached (`appliedCommands[command_id]` stores the outcome
   snapshot); refusals re-evaluate — same law as the book and the stock DO.
   `toCanonicalLease(record)` → STRICT canon shape with
   `holder: 'logistics-service:dispatch'` (exported const).
   `ASSIGNMENT_LEASE_TTL = { name: 'assignment-lease-ttl.v1', ms: 5*60*1000 }`
   with the mandated ⚠ CTO-safest-default comment. NO Date.now() anywhere in
   the pure module or the worker (asserted by a source-scan test).
2. **`worker/assignment-lease-do.ts` (new)** — thin DO `AssignmentLeaseDO` +
   router: POST `/authority/dispatch` → `idFromName('dispatch')` — ONE object
   IS the dispatch authority (SE-I01 singular; header documents the pilot-scale
   reasoning + workerd input-gate serialization per the WO). Persist only
   `ok && !idempotentReplay`. `worker/tsconfig.json` mirrors boutik's.
   Bundle: `bundle:worker` esbuild CLI → `dist-worker/assignment-worker.mjs`,
   chained via `pretest` exactly like boutik.
3. **`src/leased-assignment.ts` (new)** —
   - `LeaseAuthority { send(cmd): Promise<LeaseDecision> }` — the async DO
     boundary (production: fetch to the worker; tests: Miniflare dispatchFetch;
     sandbox: in-memory).
   - `InMemoryLeaseAuthority` — the SAME `decideLease` core held in memory,
     same persist-on-non-replay rule. This exists because the browser console
     sandbox cannot host workerd; it is NOT a second implementation of the law
     (the law lives once, in the pure function; the DO itself is the same thin
     wrapper). Documented as sandbox/unit adapter; the workerd DO is the
     authority and the e2e file proves it on the real runtime.
   - `GrantedLeaseWitness` — provenance set keyed `taskId|riderId|version`;
     `register`/`revoke`/`isGranted`. It answers "did THE authority grant this
     exact ref", not liveness (liveness is the DO's job) — defense in depth,
     never a second authority.
   - `LeasedDispatch` (deps: authority, witness, registry, queue, book,
     reschedules): `assign()` = recheckAssignable + isAssignable → DO acquire
     with the attestation `{riderAssignable, taskAssignable, checkedAt: at}`
     (the DO is the enforcement point — a false attestation refuses there,
     which is exactly the off-shift tamper surface test) → witness.register
     (non-replay grants only, see D6) → `book.assign(..., lease)` → on any
     book refusal: compensating DO release cause **'grant_rolled_back'** (the
     CTO-decided fourth cause, LOCAL vocabulary, not an event name) +
     witness.revoke.
   - `decline(assignmentId, confirmation, at)` → `book.decline` (new, below);
     only server_confirmed releases the lease (cause 'declined') + revoke.
   - `expireDue(nowIso)` → DO `expire_due` + witness.revoke each + the book's
     existing `expireUnacknowledged(nowIso)` — ONE sweep drives BOTH stores;
     TTL === ACK_DEADLINE_MS keeps them coherent (asserted).
   - `openFollowUpTask(args)` → `reschedules.openFollowUpTask`; when the prior
     task actually closed, release its lease (cause 'reschedule_closed', absorb
     `no_active_lease` — that IS "if one is active") + revoke; the follow-up
     acquires ONLY through the full `assign()` path.
   - `releaseOnCompletion(taskId)` → release cause 'completed' + revoke.
4. **`src/manual-assignment.ts` (edit)** — `LeaseRef`/`LeaseWitness` types;
   constructor gains optional witness; `assign` cmd gains REQUIRED
   `lease: LeaseRef`; after the replay check: ref-identity check
   (lease.taskId/riderId must equal the command's) then witness check —
   either failing → `{ ok: false, reason: 'no_valid_lease' }` (refuse closed).
   `AssignmentRecord` gains `lease: LeaseRef` (local audit field).
   NEW `decline(assignmentId, confirmation, at)`: must be
   active_unacknowledged | ack_pending_offline; queued_offline → pending,
   NO state change, NO event (kernel law: queued = pending, confers nothing;
   the deadline still bites); server_confirmed → `returned_to_queue` +
   `queue.requeue` + `assignment.declined.v1` (envelope exactly like the two
   existing events; actor `rider:<riderId>`; payload mirrors expired's).
   Ack stays byte-identical (ack does NOT release the lease).
5. **Existing-test updates** (each preserved assertion stated in the final
   message): `manual-assignment.test.ts` call sites gain lease refs + a
   test-local witness granting exactly what each scenario leases; NO assertion
   text weakened; `e1-dispatch-happy-path.mjs` same treatment.
6. **Rolled-back-command retry semantics (documented decision):** the DO's
   replay law means an acquire command_id whose grant was rolled back replays
   its snapshot instead of re-granting. The orchestrator registers the witness
   only for NON-replay grants, so such a retry hits `no_valid_lease` at the
   book and REFUSES CLOSED (a fresh command_id succeeds). Refuse-closed over
   silent re-grant — asserted in a test. Real surfaces mint per-attempt
   command ids (see D8).
7. **Console (item 4)** — sandbox-world builds witness + in-memory authority +
   RescheduleBook + LeasedDispatch (book now constructed WITH the witness);
   main.ts assign goes through `dispatch.assign` (async .then render);
   the proposed state renders `console.waiting_ack` (unchanged, keeps the
   existing Playwright assertion + unique `.status-line`) PLUS a new
   `.deadline-line` « Course proposée — répondez avant HH:MM » with HH:MM from
   the GRANTED LEASE's `expiresAt`; the 60 s sweep becomes
   `dispatch.expireDue(...)` and renders the honest expired state
   (`console.requeued`, copy updated to « Temps passé sans réponse. La course
   revient dans la file. ») with the task card back. New CSS class shares the
   existing token-driven rules. e2e/shell.spec.ts gains the two ordered tests
   (proposed-with-deadline · expired-returns-to-queue with page.clock).
8. **Console command ids** — the static `cmd-console-assign-<taskId>` /
   `as-<taskId>` would replay a stale success after a requeue (pre-existing
   quirk, now load-bearing with the DO): the click mints
   `…-<at>` suffixed ids so a NEW proposal after expiry is a NEW command.
   Deviation documented: required for the expired task to be honestly
   re-assignable through the leased path.
9. **Completion wiring (item 3, last bullet)** — sandbox-followup.ts is static
   data; the console has NO "marks done" surface (no delivery-completion
   action exists in the sandbox). `releaseOnCompletion` is implemented and
   asserted at the service level; I do NOT invent a fake console « done »
   action (honest-states law). Named gap, reported to the CTO in the final
   message rather than papered.
10. **Rider app (item 4)** — store: `ack` union gains `'decline_pending'`;
    `DemoCourse` gains `proposalOutcome: 'declined' | 'expired' | null`;
    `declineCourse(world, id, connectivity = CONNECTIVITY)` (the
    captureEvidence convention: offline → decline_pending, pending, confers
    nothing, course stays; online/server-confirmed → closed + 'declined');
    `expireProposal(world, id)` → closed + 'expired' (bites pending acks AND
    pending declines — the deadline law). A fifth seed (Fatou) carries the
    OFFLINE-decline pending state visibly — the exact Issouf precedent for
    seeding the offline branch. App.tsx affectation screen: deadline chip
    (« Réponds avant : HH:MM », the retry_window windowUntil pattern, 5-min ⚠
    reuse comment), DangerButton decline (the dignified-refusal pattern),
    GhostButton « Le temps est passé » demo lever (the retry.expired_action
    pattern), decline_pending PendingNotice branch; course list chips get the
    declined/expired/decline-pending honest states via statusKeyFor/toneFor.
    NO journey edge, NO custody-flow change, go/toCourses/back untouched.
11. **Copy** — all new strings in the two catalogs with register+screenClass
    tags (all instruction/status/general-class NEUTRAL register — no money
    strings needed); checked by hand against the pinned lint data (banned
    tokens, reading budgets incl. the syllable heuristic). DEVIATION: the WO
    wrote « répondez avant » for the rider line too, but the rider catalog
    tutoies throughout (« pas de toi », « Dis-nous ») — the rider line is
    « Réponds avant : » for register consistency (§10.5 warm voice); the
    console keeps the WO copy verbatim (« Course proposée — répondez avant »).
12. **Deviations from the order's letter, consolidated**: (i)
    `releaseOnCompletion(taskId)` drops the WO's `at` param — the WO's own
    release command shape carries no timestamp and LeaseRecord may not gain
    fields; (ii) rider deadline copy tu-form (D11); (iii) console assign
    command ids per-attempt (D8); (iv) no console completion surface (D9);
    (v) `console.requeued` copy updated in place to the expiry-honest text
    (no assertion referenced the old text; one key, no orphan);
    (vi) `malformed_command` boundary refusal added to the named reason set.

## C. Test plan (every new behavior asserted)
- `test/assignment-lease.test.ts` (pure): every refusal reason; replay of
  acquire/release/expire_due (same outcome, idempotentReplay, no double
  effect); refusals never cached (heal-retry); versioning (v2 after expiry;
  fresh task v1); expire_due before expiry expires nothing; release causes
  recorded incl. grant_rolled_back; TTL name+ms and === ACK_DEADLINE_MS;
  toCanonicalLease parses STRICT AssignmentLeaseSchema for all 3 statuses and
  feeds findAssignmentAuthorityViolations cleanly; no-Date.now source scan.
- `test/assignment-lease-do.e2e.test.ts` (Miniflare, real workerd): DoD ①–⑤
  exactly as ordered (20/1/19 both axes, replay, eligibility tamper, expiry +
  fresh re-acquire) + router refusals.
- `test/leased-dispatch.e2e.test.ts` (Miniflare-backed authority + real
  queue/registry/book/reschedules): full grant path; defense-in-depth bypass
  (fabricated ref AND expired-ref reuse → no_valid_lease); rollback arm
  (mixed-state rider) with cause grant_rolled_back + burned-command
  refuse-closed; decline offline-then-confirmed (+ declined event canon
  checks + lease freed with fresh version); expiry sweep drives BOTH stores +
  correlation lineage intact + next acquire version bump; reschedule closes
  prior lease + follow-up full-path grant + SE1.1 stale re-run; completion
  release.
- `manual-assignment.test.ts`: existing assertions preserved; + bypass and
  decline unit coverage where store-local.
- rider `demo-store.test.ts`: decline both arms, expiry, guards (closed/
  out-of-order throw), seed integrity.
- console e2e: the two new ordered specs.

## C. Commit 3 — the CTO ruling on the acked-expiry gap (ack ANCHORS the lease)

**The ruling, as implemented (grounds quoted in code comments):** WO-1.2's
founder-reviewed seed expires ONLY unacknowledged assignments; plan:45
"lease expiry + requeue" is the unanswered-proposal rule; the TTL is the
ANSWER deadline (« répondez avant HH:MM »). Therefore a SERVER-CONFIRMED ack
ANCHORS the lease at THE authority; an anchored lease is exempt from
expire_due and ends only by release. An offline-queued ack anchors NOTHING.
Coherence law: THE LEASE IS THE TRUTH; THE BOOK FOLLOWS IT.

**What changed (7 files, surgical):**
1. `src/assignment-lease.ts` — `LeaseRecord.anchoredAt?: string` (LOCAL;
   the canon projection is unchanged — toCanonicalLease still emits exactly
   the five §5.6 fields). New `anchor {command_id, taskId, at}` command:
   active lease → anchoredAt=at, success-cached/idempotent like the others;
   no active lease (absent/released/expired) → 'no_active_lease'; malformed
   guards (empty ids, unparseable at). `expire_due` SKIPS anchored leases.
2. `src/leased-assignment.ts` — new `acknowledge(assignmentId, confirmation,
   at)`: book.acknowledge first; server-confirmed success → anchor
   (`ack-<assignmentId>`); returns `{...ack, anchored}`. The
   anchor-refused-'no_active_lease' RACE (ack after the lease died) is
   documented in-line: anchored:false, item-3's override handles it.
   `expireDue` book arm replaced: `expireByTasks(expiredLeases.map(taskId))`
   — the book follows the lease truth.
3. `src/manual-assignment.ts` — new `expireByTasks(taskIds, nowIso)`: any
   ACTIVE_STATUSES assignment (INCLUDING 'acknowledged' — the too-late-ack
   override) carrying an expired task → returned_to_queue + requeue +
   assignment.expired.v1 (byte-same event shape/actor as the deadline-clock
   form). `expireUnacknowledged` body UNTOUCHED (its tests stand verbatim);
   only its docstring gained the ruling note. The ~20-line event-emission
   duplication between the two expiry forms is deliberate — refactoring the
   founder-reviewed method's body was out of order.
4. Tests — unit: anchor exempts from expiry (+ walls hold + release still
   ends it) · anchor on absent/released/expired refuses · anchor replay
   byte-idempotent (original instant kept) · malformed ×3. Dispatch suite:
   ruling tests ①–⑤ (see final report; ④ = the manual interleave on
   InMemoryLeaseAuthority — the SAME pure core — with the ack landing inside
   the expire_due→expireByTasks gap).
5. Wiring — `scripts/e1-dispatch-happy-path.mjs` converted to the FULL
   leased path (LeasedDispatch + InMemoryLeaseAuthority + GrantedLeaseWitness;
   assign + both acks through the orchestrator); every pre-existing printed
   line and sane-condition preserved, plus anchored=false/true proofs added
   to the output and the sane check. Console: NO ack surface exists
   (verified by grep — only the privacy-notice ack) → nothing to wire; its
   never-acked sandbox lease stays unanchored, so the expiry e2e is
   untouched and still green. Rider demo store + App.tsx: BYTE-UNTOUCHED in
   commit 3 — the demo has no server-confirmed-ack state (sandbox acks stay
   pending, and a PENDING ack still expires per the ruling), so nothing it
   shows contradicts the anchored rule.
6. Fresh-sweep-instant discipline in tests: the shared authority replays
   expire_due per command_id, so each sweep-asserting test uses its own
   nowIso (12:06/12:07/12:08/12:09) — a replayed snapshot can never fake an
   anchored-lease evaluation.
